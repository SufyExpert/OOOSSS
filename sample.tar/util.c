#include "simple.h"
#include <stdlib.h>

int load_program(const char *filename, int memory[], int mem_size) {
    FILE *fp = fopen(filename, "r");
    if (!fp) {
        perror("Error opening SML file");
        return -1;
    }

    for (int i = 0; i < mem_size; ++i) memory[i] = 0;

    int instr;
    int index = 0;
    while (fscanf(fp, "%d", &instr) == 1) {
        if (index >= mem_size) {
            fprintf(stderr, "Program too large; memory limit %d reached.\n", mem_size);
            fclose(fp);
            return -1;
        }
        memory[index++] = instr;
    }

    fclose(fp);
    return index;
}

void print_memory(int memory[], int mem_size) {
    (void) mem_size; /* only use MEMORY_SIZE = 100 */

    /* Header aligned with row labels */
    printf("\n    ");
    for (int col = 0; col < 10; ++col) printf("%8d", col);
    printf("\n\n");

    for (int row = 0; row < 10; ++row) {
        printf("%4d", row);
        for (int col = 0; col < 10; ++col) {
            int idx = row * 10 + col;
            printf("%8d", memory[idx]);
        }
        printf("\n\n");
    }
}