#ifndef SIMPLE_H
#define SIMPLE_H

#include <stdio.h>

#define MEMORY_SIZE 100

enum {
    READ = 10,
    WRITE = 11,
    LOAD = 20,
    STORE = 21,
    ADD = 30,
    SUBTRACT = 31,
    DIVIDE = 32,
    MULTIPLY = 33,
    BRANCH = 40,
    BRANCHNEG = 41,
    BRANCHZERO = 42,
    HALT = 43
};

int load_program(const char *filename, int memory[], int mem_size);

void print_memory(int memory[], int mem_size);

#endif
