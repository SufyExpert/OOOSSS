#include "simple.h"
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <sml-program-file>\n", argv[0]);
        return 1;
    }

    int memory[MEMORY_SIZE];
    if (load_program(argv[1], memory, MEMORY_SIZE) < 0) {
        fprintf(stderr, "Failed to load program '%s'\n", argv[1]);
        return 1;
    }

    int accumulator = 0;
    int instructionCounter = 0;
    int instructionRegister = 0;
    int opcode = 0;
    int operand = 0;

    printf("\nAccumulator: %d\n\nInstruction Counter (next): %d\n\nInstruction Register: %d\n\nOpcode: %d\n\nOperand: %d\n",
           accumulator, instructionCounter, instructionRegister, opcode, operand);

    print_memory(memory, MEMORY_SIZE);

    int running = 1;
    while (running) {
        if (instructionCounter < 0 || instructionCounter >= MEMORY_SIZE) {
            fprintf(stderr, "Runtime error: instruction counter out of range: %d\n", instructionCounter);
            return 1;
        }

        instructionRegister = memory[instructionCounter];
        opcode = instructionRegister / 100;
        operand = instructionRegister % 100;

        printf("\n\nExecuting instruction: %d\n\n", instructionRegister);

        switch (opcode) {
            case READ: {
                int value;
                printf("Enter a number: \n");
                while (scanf("%d", &value) != 1) {
                    printf("Invalid input. Enter an integer: \n");
                    int c;
                    while ((c = getchar()) != EOF && c != '\n');
                }
                if (operand < 0 || operand >= MEMORY_SIZE) {
                    fprintf(stderr, "Runtime error: READ operand out of range %d\n", operand);
                    return 1;
                }
                memory[operand] = value;
                instructionCounter++;
                break;
            }

            case WRITE: {
                if (operand < 0 || operand >= MEMORY_SIZE) {
                    fprintf(stderr, "Runtime error: WRITE operand out of range %d\n", operand);
                    return 1;
                }
                printf("Result: %d\n", memory[operand]);
                instructionCounter++;
                break;
            }

            case LOAD: {
                if (operand < 0 || operand >= MEMORY_SIZE) {
                    fprintf(stderr, "Runtime error: LOAD operand out of range %d\n", operand);
                    return 1;
                }
                accumulator = memory[operand];
                instructionCounter++;
                break;
            }

            case STORE: {
                if (operand < 0 || operand >= MEMORY_SIZE) {
                    fprintf(stderr, "Runtime error: STORE operand out of range %d\n", operand);
                    return 1;
                }
                memory[operand] = accumulator;
                instructionCounter++;
                break;
            }

            case ADD: {
                if (operand < 0 || operand >= MEMORY_SIZE) {
                    fprintf(stderr, "Runtime error: ADD operand out of range %d\n", operand);
                    return 1;
                }
                accumulator += memory[operand];
                instructionCounter++;
                break;
            }

            case SUBTRACT: {
                if (operand < 0 || operand >= MEMORY_SIZE) {
                    fprintf(stderr, "Runtime error: SUBTRACT operand out of range %d\n", operand);
                    return 1;
                }
                accumulator -= memory[operand];
                instructionCounter++;
                break;
            }

            case DIVIDE: {
                if (operand < 0 || operand >= MEMORY_SIZE) {
                    fprintf(stderr, "Runtime error: DIVIDE operand out of range %d\n", operand);
                    return 1;
                }
                if (memory[operand] == 0) {
                    fprintf(stderr, "Runtime error: division by zero (address %d)\n", operand);
                    return 1;
                }
                accumulator /= memory[operand];
                instructionCounter++;
                break;
            }

            case MULTIPLY: {
                if (operand < 0 || operand >= MEMORY_SIZE) {
                    fprintf(stderr, "Runtime error: MULTIPLY operand out of range %d\n", operand);
                    return 1;
                }
                accumulator *= memory[operand];
                instructionCounter++;
                break;
            }

            case BRANCH: {
                if (operand < 0 || operand >= MEMORY_SIZE) {
                    fprintf(stderr, "Runtime error: BRANCH operand out of range %d\n", operand);
                    return 1;
                }
                instructionCounter = operand;
                break;
            }

            case BRANCHNEG: {
                if (operand < 0 || operand >= MEMORY_SIZE) {
                    fprintf(stderr, "Runtime error: BRANCHNEG operand out of range %d\n", operand);
                    return 1;
                }
                if (accumulator < 0) instructionCounter = operand;
                else instructionCounter++;
                break;
            }

            case BRANCHZERO: {
                if (operand < 0 || operand >= MEMORY_SIZE) {
                    fprintf(stderr, "Runtime error: BRANCHZERO operand out of range %d\n", operand);
                    return 1;
                }
                if (accumulator == 0) instructionCounter = operand;
                else instructionCounter++;
                break;
            }

            case HALT: {
                printf("\nProgram halted (HALT instruction encountered).\n");
                running = 0;
                break;
            }

            default: {
                fprintf(stderr, "Unknown opcode %d at address %d. Halting.\n", opcode, instructionCounter);
                return 1;
            }
        }

        printf("\n----------------------------------------------------------------------------------\n");

        printf("\nAccumulator: %d\n\nInstruction Counter (next): %d\n\nInstruction Register: %d\n\nOpcode: %d\n\nOperand: %d\n",
               accumulator, instructionCounter, instructionRegister, opcode, operand);

        print_memory(memory, MEMORY_SIZE);

        /* Pause only if still running */
        if (running) {
            printf("Press Enter to execute next instruction...");
            getchar();  /* consume leftover newline */
            getchar();  /* wait for Enter */
        }
    }

    return 0;
}